/* <!-- copyright */
/*
 * aria2 - The high speed download utility
 *
 * Copyright (C) 2006 Tatsuhiro Tsujikawa
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 *
 * In addition, as a special exception, the copyright holders give
 * permission to link the code of portions of this program with the
 * OpenSSL library under certain conditions as described in each
 * individual source file, and distribute linked combinations
 * including the two.
 * You must obey the GNU General Public License in all respects
 * for all of the code used other than OpenSSL.  If you modify
 * file(s) with this exception, you may extend this exception to your
 * version of the file(s), but you are not obligated to do so.  If you
 * do not wish to do so, delete this exception statement from your
 * version.  If you delete this exception statement from all source
 * files in the program, then also delete it here.
 */
/* copyright --> */
#ifndef _D_DOWNLOAD_RESULT_H_
#define _D_DOWNLOAD_RESULT_H_

#include "common.h"

#include <stdint.h>

#include <string>
#include <vector>

#include "SharedHandle.h"
#include "DownloadResultCode.h"
#include "RequestGroup.h"
#include "Option.h"
#include "MetadataInfo.h"

namespace aria2 {

class FileEntry;

class DownloadResult
{
public:
  gid_t gid;
 
  std::vector<SharedHandle<FileEntry> > fileEntries;

  bool inMemoryDownload;

  uint64_t sessionDownloadLength;

  // milliseconds
  int64_t sessionTime;

  downloadresultcode::RESULT result;

  // This field contains GIDs. See comment in
  // RequestGroup.cc::_followedByGIDs.
  std::vector<gid_t> followedBy;

  // This field contains GID. See comment in
  // RequestGroup.cc::_belongsToGID.
  gid_t belongsTo;

  SharedHandle<Option> option;

  SharedHandle<MetadataInfo> metadataInfo;

  DownloadResult(gid_t gid,
                 const std::vector<SharedHandle<FileEntry> >& fileEntries,
                 bool inMemoryDownload,
                 uint64_t sessionDownloadLength,
                 int64_t sessionTime,
                 downloadresultcode::RESULT result,
                 const std::vector<gid_t> followedBy,
                 gid_t belongsTo,
                 const SharedHandle<Option>& option,
                 const SharedHandle<MetadataInfo>& metadataInfo):
    gid(gid),
    fileEntries(fileEntries),
    inMemoryDownload(inMemoryDownload),
    sessionDownloadLength(sessionDownloadLength),
    sessionTime(sessionTime),
    result(result),
    followedBy(followedBy),
    belongsTo(belongsTo),
    option(option),
    metadataInfo(metadataInfo) {}
};

typedef SharedHandle<DownloadResult> DownloadResultHandle;

} // namespace aria2

#endif // _D_DOWNLOAD_RESULT_H_
