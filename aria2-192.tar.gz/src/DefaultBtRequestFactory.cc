/* <!-- copyright */
/*
 * aria2 - The high speed download utility
 *
 * Copyright (C) 2006 Tatsuhiro Tsujikawa
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA
 *
 * In addition, as a special exception, the copyright holders give
 * permission to link the code of portions of this program with the
 * OpenSSL library under certain conditions as described in each
 * individual source file, and distribute linked combinations
 * including the two.
 * You must obey the GNU General Public License in all respects
 * for all of the code used other than OpenSSL.  If you modify
 * file(s) with this exception, you may extend this exception to your
 * version of the file(s), but you are not obligated to do so.  If you
 * do not wish to do so, delete this exception statement from your
 * version.  If you delete this exception statement from all source
 * files in the program, then also delete it here.
 */
/* copyright --> */
#include "DefaultBtRequestFactory.h"

#include <algorithm>

#include "LogFactory.h"
#include "Logger.h"
#include "Piece.h"
#include "Peer.h"
#include "PieceStorage.h"
#include "BtMessageDispatcher.h"
#include "BtMessageFactory.h"
#include "BtMessage.h"
#include "a2functional.h"
#include "SimpleRandomizer.h"
#include "array_fun.h"

namespace aria2 {

DefaultBtRequestFactory::DefaultBtRequestFactory():
  cuid(0),
  _logger(LogFactory::getInstance())
{
  if(_logger->debug()) {
    _logger->debug("DefaultBtRequestFactory::instantiated");
  }
}

DefaultBtRequestFactory::~DefaultBtRequestFactory()
{
  if(_logger->debug()) {
    _logger->debug("DefaultBtRequestFactory::deleted");
  }
}

void DefaultBtRequestFactory::addTargetPiece(const SharedHandle<Piece>& piece)
{
  pieces.push_back(piece);
}

class AbortCompletedPieceRequest
{
private:
  WeakHandle<BtMessageDispatcher> _dispatcher;
public:
  AbortCompletedPieceRequest(const WeakHandle<BtMessageDispatcher>& dispatcher):
    _dispatcher(dispatcher) {}

  void operator()(const SharedHandle<Piece>& piece)
  {
    if(piece->pieceComplete()) {
      _dispatcher->doAbortOutstandingRequestAction(piece);
    }
  }
};

void DefaultBtRequestFactory::removeCompletedPiece() {
  std::for_each(pieces.begin(), pieces.end(),
                AbortCompletedPieceRequest(dispatcher));
  pieces.erase(std::remove_if(pieces.begin(), pieces.end(),
                              mem_fun_sh(&Piece::pieceComplete)),
               pieces.end());
}

void DefaultBtRequestFactory::removeTargetPiece(const SharedHandle<Piece>& piece) {
  pieces.erase(std::remove(pieces.begin(), pieces.end(), piece),
               pieces.end());
  dispatcher->doAbortOutstandingRequestAction(piece);
  _pieceStorage->cancelPiece(piece);
}

class ProcessChokedPiece {
private:
  SharedHandle<Peer> _peer;
  WeakHandle<PieceStorage> _pieceStorage;
public:
  ProcessChokedPiece(const SharedHandle<Peer>& peer,
                     const WeakHandle<PieceStorage>& pieceStorage):
    _peer(peer),
    _pieceStorage(pieceStorage) {}

  void operator()(const SharedHandle<Piece>& piece)
  {
    if(!_peer->isInPeerAllowedIndexSet(piece->getIndex())) {
      _pieceStorage->cancelPiece(piece);
    }
  }
};

class FindChokedPiece {
private:
  SharedHandle<Peer> _peer;
public:
  FindChokedPiece(const SharedHandle<Peer>& peer):_peer(peer) {}

  bool operator()(const SharedHandle<Piece>& piece)
  {
    return !_peer->isInPeerAllowedIndexSet(piece->getIndex());
  }
};

void DefaultBtRequestFactory::doChokedAction()
{
  std::for_each(pieces.begin(), pieces.end(),
                ProcessChokedPiece(peer, _pieceStorage));
  pieces.erase(std::remove_if(pieces.begin(), pieces.end(),
                              FindChokedPiece(peer)),
               pieces.end());
}

void DefaultBtRequestFactory::removeAllTargetPiece() {
  for(std::deque<SharedHandle<Piece> >::iterator itr = pieces.begin(),
        eoi = pieces.end(); itr != eoi; ++itr) {
    dispatcher->doAbortOutstandingRequestAction(*itr);
    _pieceStorage->cancelPiece(*itr);
  }
  pieces.clear();
}

void DefaultBtRequestFactory::createRequestMessages
(std::vector<SharedHandle<BtMessage> >& requests, size_t max)
{
  if(requests.size() >= max) {
    return;
  }
  size_t getnum = max-requests.size();
  std::vector<size_t> blockIndexes;
  blockIndexes.reserve(getnum);
  for(std::deque<SharedHandle<Piece> >::iterator itr = pieces.begin(),
        eoi = pieces.end(); itr != eoi && getnum; ++itr) {
    SharedHandle<Piece>& piece = *itr;
    if(piece->getMissingUnusedBlockIndex(blockIndexes, getnum)) {
      getnum -= blockIndexes.size();
      for(std::vector<size_t>::const_iterator i = blockIndexes.begin(),
            eoi2 = blockIndexes.end(); i != eoi2; ++i) {
        if(_logger->debug()) {
          _logger->debug("Creating RequestMessage index=%u, begin=%u,"
                         " blockIndex=%u",
                         piece->getIndex(),
                         (*i)*piece->getBlockLength(),
                         (*i));
        }
        requests.push_back
          (messageFactory->createRequestMessage(piece, *i));
      }
      blockIndexes.clear();
    }
  }
}

void DefaultBtRequestFactory::createRequestMessagesOnEndGame
(std::vector<SharedHandle<BtMessage> >& requests, size_t max)
{
  for(std::deque<SharedHandle<Piece> >::iterator itr = pieces.begin(),
        eoi = pieces.end(); itr != eoi && requests.size() < max; ++itr) {
    SharedHandle<Piece>& piece = *itr;
    const size_t mislen = piece->getBitfieldLength();
    array_ptr<unsigned char> misbitfield(new unsigned char[mislen]);

    piece->getAllMissingBlockIndexes(misbitfield, mislen);

    std::vector<size_t> missingBlockIndexes;
    size_t blockIndex = 0;
    for(size_t i = 0; i < mislen; ++i) {
      unsigned char bits = misbitfield[i];
      unsigned char mask = 128;
      for(size_t bi = 0; bi < 8; ++bi, mask >>= 1, ++blockIndex) {
        if(bits & mask) {
          missingBlockIndexes.push_back(blockIndex);
        }
      }
    }
    std::random_shuffle(missingBlockIndexes.begin(), missingBlockIndexes.end(),
                        *(SimpleRandomizer::getInstance().get()));
    for(std::vector<size_t>::const_iterator bitr = missingBlockIndexes.begin(),
          eoi2 = missingBlockIndexes.end();
        bitr != eoi2 && requests.size() < max; ++bitr) {
      const size_t& blockIndex = *bitr;
      if(!dispatcher->isOutstandingRequest(piece->getIndex(),
                                           blockIndex)) {
        if(_logger->debug()) {
          _logger->debug("Creating RequestMessage index=%u, begin=%u,"
                         " blockIndex=%u",
                         piece->getIndex(),
                         blockIndex*piece->getBlockLength(),
                         blockIndex);
        }
        requests.push_back(messageFactory->createRequestMessage(piece, blockIndex));
      }
    }
  }
}

class CountMissingBlock
{
private:
  size_t _numMissingBlock;
public:
  CountMissingBlock():_numMissingBlock(0) {}

  size_t getNumMissingBlock()
  {
    return _numMissingBlock;
  }

  void operator()(const SharedHandle<Piece>& piece)
  {
    _numMissingBlock += piece->countMissingBlock();
  }
};

size_t DefaultBtRequestFactory::countMissingBlock()
{
  return std::for_each(pieces.begin(), pieces.end(),
                       CountMissingBlock()).getNumMissingBlock();
}

void DefaultBtRequestFactory::getTargetPieceIndexes
(std::vector<size_t>& indexes) const
{
  std::transform(pieces.begin(), pieces.end(), std::back_inserter(indexes),
                 mem_fun_sh(&Piece::getIndex));
}

void DefaultBtRequestFactory::setPieceStorage
(const SharedHandle<PieceStorage>& pieceStorage)
{
  _pieceStorage = pieceStorage;
}

void DefaultBtRequestFactory::setPeer(const SharedHandle<Peer>& peer)
{
  this->peer = peer;
}

void DefaultBtRequestFactory::setBtMessageDispatcher(const WeakHandle<BtMessageDispatcher>& dispatcher)
{
  this->dispatcher = dispatcher;
}

void DefaultBtRequestFactory::setBtMessageFactory(const WeakHandle<BtMessageFactory>& factory)
{
  this->messageFactory = factory;
}

} // namespace aria2
