To produce aria2c.1:

a2x  -f manpage aria2c.1.txt

You may have to insert line break before '.sp' in output file.
