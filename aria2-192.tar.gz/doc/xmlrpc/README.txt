This directory contains sample scripts to interact with aria2 via
XML-RPC. For more information, see
http://sourceforge.net/apps/trac/aria2/wiki/XmlrpcInterface
